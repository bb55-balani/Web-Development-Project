<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap.css">
</head>

<body>
    <div class="container-fluid">
        <div class="row p-2 mt-4 d-flex justify-content-around">
            <div class="col-md-5 border bg-danger text-white rounded" style="height: 150px;">
                <p class="display-4">Total Blood Donation</p>
                <span class="h2 bg-white text-danger mt-2 d-flex justify-content-center">
                <?php
                    require_once '../connect.php';
                    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM `tbl_donation`");
                    $row = mysqli_fetch_assoc($result);
                    $count = $row['count'];
                    echo $count . " donation's";
                ?>
                &nbsp;<a href="blood_history.php" class="h6 mt-3 ml-4">See Records</a>
                </span>
            </div>
            <div class="col-md-5 border bg-danger text-white rounded" style="height: 150px;">
                <p class="display-4">Total Blood Request</p>
                <span class="h2 bg-white text-danger mt-2 d-flex justify-content-center">
                <?php
                    require_once '../connect.php';
                    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM `tbl_request`");
                    $row = mysqli_fetch_assoc($result);
                    $count = $row['count'];
                    echo $count . " request's";
                ?>
                &nbsp;<a href="blood_request.php" class="h6 mt-3 ml-5">See Records</a>
                </span>
            </div>
        </div>
        <div class="row p-2 mt-3 d-flex justify-content-around">
            <div class="col-md-5 border bg-danger text-white rounded" style="height: 150px;">
                <p class="display-4">Total Donor's</p>
                <span class="h2 bg-white text-danger mt-2 d-flex justify-content-center">
                <?php
                    require_once '../connect.php';
                    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM `tbl_donor_registration`");
                    $row = mysqli_fetch_assoc($result);
                    $count = $row['count'];
                    echo $count . " donor's";
                    ?>
                    &nbsp;<a href="donors.php" class="h6 mt-3 ml-5">See Records</a>
                    </span>
            </div>
            <div class="col-md-5 border bg-danger text-white rounded" style="height: 150px;">
                <p class="display-4">Total User's</p>
                <span class="h2 bg-white text-danger mt-2 d-flex justify-content-center">
                <?php
                    require_once '../connect.php';
                    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM `tbl_user_registration`");
                    $row = mysqli_fetch_assoc($result);
                    $count = $row['count'];
                    echo $count . " user's";
                ?>
                &nbsp;<a href="users.php" class="h6 mt-3 ml-5">See Records</a>
                </span>
            </div>
        </div>
        <div class="row p-2 mt-4 d-flex justify-content-around">
            <div class="col-md-5 border bg-danger text-white rounded" style="height: 150px;">
                <p class="display-4">Total Events</p>
                <span class="h2 bg-white text-danger mt-2 d-flex justify-content-center">
                <?php
                    require_once '../connect.php';
                    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM `tbl_events`");
                    $row = mysqli_fetch_assoc($result);
                    $count = $row['count'];
                    echo $count . " event's";
                ?>
                &nbsp;<a href="events.php" class="h6 mt-3 ml-5">See Records</a>
                </span>
            </div>
            <div class="col-md-5 border bg-danger text-white rounded" style="height: 150px;">
                <p class="display-4">Total Payment</p>
                <span class="h2 bg-white text-danger mt-2 d-flex justify-content-center">
                <?php
                    require_once '../connect.php';
                    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM `tbl_payment`");
                    $row = mysqli_fetch_assoc($result);
                    $count = $row['count'];
                    echo $count . " payment's";
                ?>
                &nbsp;<a href="payments.php" class="h6 mt-3 ml-5">See Records</a>
                </span>
            </div>
        </div>
        
    </div>
</body>

</html>