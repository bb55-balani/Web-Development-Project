<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap.css">
</head>
<body>
        <div class="conatiner">
            <div class="row ml-2">
                <div class="bg-success text-white display-4 col-md-4 m-2">Blood Group Report<br>
                <button class="btn btn-danger"><a href="/reports/donation/_donation_reportrpt.php" class="text-white" target="blank">Generate Pdf</a></button>
                </div>
                <div class="bg-success text-white display-4 col-md-3 m-2">Donor's Report<br>
                <button class="btn btn-danger"><a href="" class="text-white" target="blank">Generate Pdf</a></button>
                </div>
                <div class="bg-success text-white display-4 col-md-4 m-2">User's Report<br>
                <button class="btn btn-danger"><a href="" class="text-white" target="blank">Generate Pdf</a></button>
                </div>
            </div>
            <div class="row ml-2">
                <div class="bg-success text-white display-4 col-md-4 m-2">Payment Report<br>
                <button class="btn btn-danger"><a href="" class="text-white" target="blank">Generate Pdf</a></button>
                </div>
                <div class="bg-success text-white display-4 col-md-3 m-2">Donation Report<br>
                <button class="btn btn-danger"><a href="" class="text-white" target="blank">Generate Pdf</a></button>
                </div>
                <div class="bg-success text-white display-4 col-md-4 m-2">Feedback Report<br>
                <button class="btn btn-danger"><a href="" class="text-white" target="blank">Generate Pdf</a></button>
                </div>
                <div class="bg-success text-white display-4 col-md-4 m-2">Blood Request Report<br>
                <button class="btn btn-danger"><a href="" class="text-white" target="blank">Generate Pdf</a></button>
                </div>
            </div>
        </div>
    </body>
</html>