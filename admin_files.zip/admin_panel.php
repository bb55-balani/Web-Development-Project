<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
    </script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css"
        integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" -->
    integrity = "sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s"
    crossorigin = "anonymous" >
    </script>
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    /* .nav-link:hover{
            background-color:white;
            color:black;
        } */
    </style>
</head>

<body>
    <?php
        require_once '../connect.php';
    ?>
    <div class="conatiner">
        <div class="row bg-success" style="background-color:#DF3C5F;">
            <div class="col display-4 py-2 text-white text-center">
                <img src="images/header.png" alt="" class="img-fluid" width="80px">Blood Donation Management System
            </div>
        </div>
    </div>
    <div class="conatiner">
        <div class="row bg-dark">
            <div class="col-md-2 text-justify bg-light">
                <nav class="navbar-nav nav-pills m-md-3">
                    <li class="nav-item h2">
                        <a href="home_page.php" target="display" class="nav-link p-2 mt-4 shadow-lg rounded"><img src="images/home.png" alt=""
                                class="img-fluid" width="42px"> Dashboard</a>
                    </li>
                    <!-- <li class="nav-item h2">
                        <a href="" class="nav-link p-2 mb-5 mt-4 shadow-lg rounded">Dashboard</a>
                    </li> -->
                    <li class="nav-item h2">
                        <a href="donors.php" target="display" class="nav-link p-2 mt-4 shadow-lg rounded">
                            <img src="images/donnor.jpg" alt="" class="img-fluid" width="50px">Donor</a>
                    </li>
                    <li class="nav-item h2">
                        <a href="users.php" target="display" class="nav-link p-2 mt-4 shadow-lg rounded">
                            <img src="images/request.png" alt="" class="img-fluid" width="50px">Patient</a>
                    </li>
                    <li class="nav-item h2">
                        <a href="blood_history.php" target="display"  class="nav-link mt-4 shadow-lg rounded">
                            <img src="images/donation.png" alt="" class="img-fluid" width="40px"> Blood-History</a>
                    </li>
                    <li class="nav-item h2">
                        <a href="blood_request.php" target="display" class="nav-link p-2 mt-4 shadow-lg rounded"><img src="images/blood_request.png"
                                alt="" class="img-fluid" width="38px">Blood-Request</a>
                    </li>
                    <!-- <li class="nav-item h2">
                        <a href="" class="nav-link p-2 mt-4 shadow-lg rounded" target="display"><img src="images/stock.png" alt=""
                                class="img-fluid" width="50px">Blood Stock</a>
                    </li> -->
                    <li class="nav-item h2">
                        <a href="events.php" class="nav-link p-2 mt-4 shadow-lg rounded" target="display"><img src="images/event.png" alt=""
                                class="img-fluid" width="45px"> Events</a>
                    </li>
                    <li class="nav-item h2">
                        <a href="payments.php" class="nav-link p-2 mt-4 shadow-lg rounded" target="display"><img src="images/rupees.png" alt=""
                                class="img-fluid" width="50px"> Payments</a>
                    </li>
                    <li class="nav-item h2">
                        <a href="" class="nav-link p-2 mt-4 shadow-lg rounded" target="display"><img src="images/rupees.png" alt=""
                                class="img-fluid" width="50px">Feedback</a>
                    </li>
                    <li class="nav-item h2">
                        <a href="reports.php" class="nav-link p-2 mt-4 shadow-lg rounded" target="display"><img src="images/rupees.png" alt=""
                                class="img-fluid" width="50px">Reports</a>
                    </li>
                    <!-- <li class="nav-item h2">
                        <a href="payments.php" class="nav-link p-2 mt-4 shadow-lg rounded" target="display"><img src="images/stock.png" alt=""
                                class="img-fluid" width="50px"> Blood Stock</a>
                    </li> -->
                </nav>
            </div>
            <div class="col text-white mt-5 ml-2">
                <iframe src="home_page.php" frameborder="" name="display" width="1580px" height="80%">
                    </iframe>
                </div>
            </div>
    </div>
</body>

</html>