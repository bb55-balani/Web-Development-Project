<?php
session_start();
$html = $_SESSION['user'];
echo $html;
echo "<script> window.print(); </script>";
?>