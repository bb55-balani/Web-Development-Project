<?php 
require_once '../connect.php';

    $did = $_REQUEST['Donor_id'];
    $q2 = "DELETE FROM `tbl_donor_registration` WHERE Donor_id = '$did'";
    if(mysqli_query($conn,$q2)){
        header('Location:home_page.php');
    }
    else{
        echo "Error in Deleting Record!!".mysqli_error($conn);
    }
    mysqli_close($conn);
?>