<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- for css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <!-- for js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
    </script>
    <!-- for icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="bootstrap.css">
    <!-- font icons -->
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css"
        integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">
    <!-- for navbar button -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <!-- <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"
        integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous">
    </script>
</head>
<body>
    <?php
        require_once '../connect.php';
    ?>
          
    <table class="table bg-dark text-white table-bordered table-striped table-sm">
        <tr class="font-weight-bolder h3 text-center text-white">
            <th class="text-white">Payment_id</th>
            <th class="text-white">Full Name</th>
            <th class="text-white">Email</th>
            <th class="text-white">Blood_grp</th>
            <th class="text-white">Total_units</th>
            <th class="text-white">Price_per_unit</th>
            <th class="text-white">Total_amt</th>
            <th class="text-white">User_id</th>
        </tr>
        <?php
            $sql = "SELECT * FROM `tbl_payment`";
            $result = mysqli_query($conn,$sql);
            if(mysqli_num_rows($result)>0){
                while($row=mysqli_fetch_assoc($result))
                {
                    echo '<tr class="bg-light text-dark text-justify">';
                    echo '<td>'.$row['Payment_id'].'</td>';
                    echo '<td>'.$row['Full Name'].'</td>';
                    echo '<td>'.$row['Email'].'</td>';
                    echo '<td>'.$row['Blood_grp'].'</td>';
                    echo '<td>'.$row['Total_units'].'</td>';
                    echo '<td>'.$row['Price_per_unit'].'</td>';
                    echo '<td>'.$row['Total_amt'].'</td>';
                    echo '<td>'.$row['User_id'].'</td>';
                    echo    '<td class="bg-dark" style="width: 100px;">'.'<button class="btn btn-success">'.'<a href="" class="text-white"><i class="bi bi-pencil"></i></a>'.'</button>'.'   '.
                            '<button class="btn btn-danger">'.'<a href="" class="text-white"><i class="bi bi-trash3"></i></a>'.'</button>'.'</td>'; 
                    echo '</tr>';
                }
            }
        ?>
    </table>
</body>
</html>